Create table Hospital 
(
Hospital_name VARCHAR(100),
Location VARCHAR(100),
Department VARCHAR(100),
Doctors_count int,
Patients_count int,
Admission_date date,
Discharge_date date,
Medical_expenses NUMERIC(10,2)
);

select * from hospital;

copy hospital(Hospital_name,Location,Department,Doctors_count,Patients_count,Admission_date,Discharge_date,Medical_expenses)
from 'D:\Onedrive\Desktop\HR Analytics\PosetgreSQL\30 Days SQL Course Assignment\Hospital_Data.csv'
csv header;


-- 1] Write an SQL query to find the total number of patients across all hospitals.
SELECT SUM(patients_count) AS Total_patients
FROM hospital;

-- 2] Retrieve the average count of doctors available in each hospital.
SELECT hospital_name,AVG(doctors_count) AS Average_doctors_available
FROM hospital
GROUP BY hospital_name;

-- 3] Find the top 3 hospital departments that have the highest number of patients.
SELECT department,patients_count
FROM hospital
ORDER BY patients_count DESC
LIMIT 3;

-- 4] Identify the hospital that recorded the highest medical expenses.
SELECT hospital_name,SUM(medical_expenses)
FROM hospital
group by hospital_name
LIMIT 1;


-- 5] Calculate the average medical expenses per day for each hospital.
SELECT hospital_name,admission_date,AVG(medical_expenses) AS Avg_Daily_expenses
FROM hospital
GROUP BY hospital_name,admission_date;

-- 6] Find the patient with the longest stay by calculating the difference between Discharge Date and Admission Date.
SELECT Hospital_name,Admission_date,Discharge_date,
(Discharge_date-Admission_date) AS Longest_stay_duration
FROM Hospital
ORDER BY Longest_stay_duration DESC
LIMIT 1;


-- 7] Count the total number of patients treated in each city.
SELECT location,SUM(patients_count) AS Total_Patients_treated
FROM hospital
GROUP BY location
ORDER BY location ASC;


-- 8] Calculate the average number of days patients spend in each department.
SELECT department,AVG(discharge_date-admission_date) AS Avg_No_of_days
FROM hospital
GROUP BY department
ORDER BY department ASC;

-- 9] Find the department with the least number of patients.
SELECT department,SUM(patients_count) AS Number_of_patients
FROM hospital
GROUP BY department
order by Number_of_patients ASC
LIMIT 1;

-- 10] Group the data by month and calculate the total medical expenses for each month.
SELECT DATE_TRUNC('month',admission_date) as Month_expense,
sum(medical_expenses) as Monthly_medical_expenses
FROM hospital
group by Month_expense
order by Month_expense ASC;


